#include<stdio.h>
#include<string.h>
#include "structures.h"
#include "epass.h"
#include "foodo.h"
#include<stdlib.h>
#include<windows.h>
#include<conio.h>
static int input,t_index=0,m=1,f=1;
void Trains_list()
{
    FILE *fp=fopen("E:\\Trains_list.txt","w");
	int trainArraySize = 5;
	Trains trains[5]={{12267,"AC Duronto Express","Mumbai","Ahmedabad","23:25","05:55",630},{12426,"Rajdhani Express","Jammu","New Delhi","19:40","05:05",725},{12307,"Super Fast Express","Howrah","Jodhpur\t","23:30","08:30",2260},{12506,"North East Express","Delhi","Guwahati","06:45","16:50",2290},{22204,"Rajdhani Express","Mumbai","New Delhi","16:35","08:35",1698}};
	for(int i=0;i<trainArraySize;i++)
	{
		Trains train = trains[i];
		fwrite(&train,sizeof(Trains),1,fp);
	}
    fclose(fp);
}
void Train_Schedule()
{
    system("cls");
    Trains tr;
    FILE *fp=fopen("E:\\Trains_list.txt","r");
    printf("\t\t\t\t\t");
    for(int i=0;i<110;i++)
        printf("-");
    printf("\n\t\t\t\t\t");
    for(int i=0;i<110;i++)
        printf("-");
    printf("\n\t\t\t\t\t\t");
    printf("\t\t\t\t\t");
    printf("Train Schedule\n");
    printf("\t\t\t\t\t");
    for(int i=0;i<110;i++)
        printf("-");
    printf("\n\t\t\t\t\t");
    for(int i=0;i<110;i++)
        printf("-");
    printf("\n\t\t\t\t\t");
    printf("Train no.\tTrain name\t\t\tSource\t\tDestination\tArrival time\tDeparture time\n");
    printf("\t\t\t\t\t");
    for(int i=0;i<110;i++)
        printf("-");
    while(fread(&tr,sizeof(Trains),1,fp))
        printf("\n\t\t\t\t\t%d\t\t%s\t\t%s\t\t%s\t%s\t\t%s\n",tr.train_no,tr.train_name,tr.from,tr.to,tr.arr_time,tr.dep_time);
    fclose(fp);
    printf("\t\t\t\t\t");
    for(int i=0;i<110;i++)
        printf("-");
    printf("\n\t\t\t\t\t");
    for(int i=0;i<110;i++)
        printf("-");
    printf("\n\nPress any key to go back to main menu");
    getch();
    system("cls");
    menu();
}

void Show_Train_Schedule(){
	system("cls");
    Trains tr;
    FILE *fp=fopen("E:\\Trains_list.txt","r");
    printf("\t\t\t\t\t");
    for(int i=0;i<110;i++)
        printf("-");
    printf("\n\t\t\t\t\t");
    for(int i=0;i<110;i++)
        printf("-");
    printf("\n\t\t\t\t\t\t");
    printf("\t\t\t\t\t");
    printf("Train Schedule\n");
    printf("\t\t\t\t\t");
    for(int i=0;i<110;i++)
        printf("-");
    printf("\n\t\t\t\t\t");
    for(int i=0;i<110;i++)
        printf("-");
    printf("\n\t\t\t\t\t");
    printf("Train no.\tTrain name\t\t\tSource\t\tDestination\tArrival time\tDeparture time\n");
    printf("\t\t\t\t\t");
    for(int i=0;i<110;i++)
        printf("-");
    while(fread(&tr,sizeof(Trains),1,fp))
        printf("\n\t\t\t\t\t%d\t\t%s\t\t%s\t\t%s\t%s\t\t%s\n",tr.train_no,tr.train_name,tr.from,tr.to,tr.arr_time,tr.dep_time);
    fclose(fp);
    printf("\t\t\t\t\t");
    for(int i=0;i<110;i++)
        printf("-");
    printf("\n\t\t\t\t\t");
    for(int i=0;i<110;i++)
        printf("-");
}

void Book_Tickets()
{
    pass_t p[100];
    int tr_no,i,j=0,g;
    char ch,c,str[5],cc;
    Trains tr;
    FILE *fp=fopen("E:\\Trains_list.txt","rb");
    label:
        system("cls");
		Show_Train_Schedule();
        printf("\n\n:::Ticket Booking Counter:::\n");
        printf("Enter train no.:");
        scanf("%d",&tr_no);
        for(i=1;i<6;i++)
        {
            fread(&tr,sizeof(Trains),1,fp);
            if(tr_no==tr.train_no)
                j=i;
        }
    if(j!=0)
    {
        p[t_index].train_no=tr_no;
        printf("Enter the details:\n");
        while((getchar())!='\n');
        printf("Passenger name:");
        gets(p[t_index].name);
        printf("Age:");
        scanf("%d",&p[t_index].age);
        label1:
        printf("Gender(1.Male 2.Female 3.Other) :");
        scanf("%d",&g);
        while((getchar())!='\n');
        if(g==1||g==2||g==3)
        {
            switch(g)
            {
                case 1:
                    strcpy(p[t_index].gender,"Male");
                    break;
                case 2:
                    strcpy(p[t_index].gender,"Female");
                    label3:
                    printf("Would you like to travel with female co-passengers?(y/n):");
                    scanf("%c",&cc);
                    if(cc=='y'||cc=='Y')
                    {
                        if(f<11)
                        {
                            p[t_index].seat_no=f;
                            f++;
                        }
                        else
                        {
                            printf("Sorry no seats available");
                        }
                    }
                    else if((cc=='n')||(cc=='N'))
                    {
                        p[t_index].seat_no=0;
                    }
                    else
                    {
                        printf("Invalid input! Try again");
                        goto label3;
                    }
                    while((getchar())!='\n');
                    break;
                case 3:
                    strcpy(p[t_index].gender,"Other");
                    break;
            }
        }
        else
        {
            printf("\nInvalid input! Try again\n");
            goto label1;
        }
        label2:
        printf("Phone number:");
        gets(p[t_index].phone_no);
        if(strlen(p[t_index].phone_no)<10)
        {
            printf("\nInvalid input! Try again\n");
            goto label2;
        }
        printf("Do you want to confirm your booking?(y/n)");
        c=getch();
        printf("%c",c);
        if(c=='y'||c=='Y')
        {
            printf("\nYour ticket has been booked successfully!\n");
            itoa(t_index+1,str,10);
            strcpy(p[t_index].png_code,"PNG_");
            strcat(p[t_index].png_code,str);
            if((g==1||g==3)||(g==2&&p[t_index].seat_no==0))
            {
                p[t_index].seat_no=m+10;
                m++;
            }
            strcpy(p[t_index].train_name,tr.train_name);
            p[t_index].t_fare=tr.fare;
            printf("\nWait till your ticket is being generated...");
            Sleep(1000);
            system("cls");
            char pcode[50],tN[50],pN[50];
            strcpy(pcode, p[t_index].png_code);
            strcpy(tN, p[t_index].train_name);
            strcpy(pN, p[t_index].name);
            int tn = p[t_index].train_no;
            int sn = p[t_index].seat_no;
            FILE *tt;
            tt=fopen("tickets.txt","a");
            fprintf(tt,"Passenger code: %s||Train no.: %d||Train name: %s||Passenger name: %s||Seat number: %d||\n",pcode,tn,tN,pN,sn);
            fclose(tt);
            printf("\n\nTicket details:\n");
            printf("Passenger code: %s\nTrain no.: %d\nTrain name: %s\nSource: %s\nDestination: %s\nPassenger name: %s\nAge: %d\nGender: %s\nPhone number: %s\nSeat number:%d\nTicket Fare:%d\n",p[t_index].png_code,p[t_index].train_no,p[t_index].train_name,tr.from,tr.to,p[t_index].name,p[t_index].age,p[t_index].gender,p[t_index].phone_no,p[t_index].seat_no,p[t_index].t_fare);
			t_index++;
            j=0;
        }
    }
    else
    {
        printf("Invalid train number\n");
        printf("Do you want to try again?(y/n)");
        ch=getch();
        printf("%c",ch);
        if(ch=='y'||ch=='Y')
        {
            goto label;
        }
    }
    fclose(fp);
    printf("\n\nPress any key to go back to main menu");
    getch();
    system("cls");
    menu();
}
void View_Tickets()
{
    system("cls");
    FILE *fptr = fopen("tickets.txt", "r");
    printf(":::Ticket Details:::\n\n");
    char ch = fgetc(fptr);
    while (ch != EOF)
    {
        printf ("%c", ch);
        ch = fgetc(fptr);
    }
    fclose(fptr);
    printf("\n\nPress any key to go back to main menu");
    getch();
    system("cls");
    menu();
}

void View_File(char* filename)
{
    FILE *fptr = fopen(filename, "r");
    printf(":::File Contents:::\n\n");
    char ch = fgetc(fptr);
    while (ch != EOF)
    {
        printf ("%c", ch);
        ch = fgetc(fptr);
    }
    printf("\n\nPress any key to go back to main menu");
    getch();
    menu();
}

void tryCancel(char* pcode)
{
    FILE *fp;
    FILE *tempfp;
    char str[MAXCHAR];
    char* filename = "tickets.txt";
    char* tempfile = "temptickets.txt";

    fp = fopen(filename, "r");
    tempfp = fopen(tempfile,"w");
    if (fp == NULL)
    {
        printf("Could not open file %s",filename);
        return 1;
    }
    if (tempfp == NULL){
        printf("Could not open file %s",tempfile);
        return 1;
    }
    while (fgets(str, MAXCHAR, fp) != NULL)
    {
        if (strstr(str, pcode) != NULL)
        {
            printf("\nThe following ticket will be cancelled:\n");
            printf("%s", str);
        }
        else
        {
            fprintf(tempfp,"%s",str);
        }
    }
    printf("\nTicket cancellation process completed!\n\n");
    fclose(fp);
    fclose(tempfp);
    remove(filename);
    rename(tempfile,filename);
}

void Cancel_Tickets()
{
    system("cls");
    char pcode[20];
    printf("Enter passenger code :");
    scanf("%s",pcode);
    FILE*fp1=fopen("tickets.txt","r");
    if(fp1==NULL)
    {
        printf("\nNo bookings done yet");
    }
    fclose(fp1);
    tryCancel(pcode);
    printf("\n\nPress any key to go back to main menu");
    getch();
    system("cls");
    menu();
}
void Food_Reservation()
{
    mainmenuf();
}
void E_pass()
{
    mainmenu_e();
}
void menu()
{
    for(int i=0;i<422;i++)
    {
        printf("-");
    }
    printf("\t\t\t\t\t\t\t");
    printf("\t\t\t\t\t");
    printf("RAILWAY TICKET RESERVATION SYSTEM\n");
    for(int i=0;i<422;i++)
    {
        printf("-");
    }
    printf(":::Main Menu:::\n");
    printf("1. Train Schedule\n");
    printf("2. Booking Tickets\n");
    printf("3. Cancelling Tickets\n");
    printf("4. View Booked Tickets\n");
    printf("5. Food Reservation\n");
    printf("6. E-pass\n");
    printf("7. Exit\n");
    printf("Choose an option: ");
    scanf("%d",&input);
    Input();
}
void Input()
{
    Trains_list();
    if(input==1)
        Train_Schedule();
    else if(input==2)
        Book_Tickets();
    else if(input==3)
        Cancel_Tickets();
    else if(input==4)
        View_Tickets();
    else if(input==5)
        Food_Reservation();
    else if(input==6)
        E_pass();
    else if(input==7)
        exit(0);
    else
    {
        printf("Invalid input!");
        Sleep(1000);
        system("cls");
        menu();
    }
}
int main(void)
{
    First_page();
    Login_Register();
    menu();
    return 0;
}

