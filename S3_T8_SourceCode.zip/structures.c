void Trains_list();
void menu();
void INPUT();
void Book_Tickets();
void Cancel_Tickets();

