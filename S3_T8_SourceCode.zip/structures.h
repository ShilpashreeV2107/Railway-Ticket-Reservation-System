#ifndef STRUCTURES_H_INCLUDED
#define STRUCTURES_H_INCLUDED
struct Train
{
    int train_no;
    char train_name[50];
    char from[50];
    char to[50];
    char dep_time[10];
    char arr_time[10];
    int fare;
    int f_seats;
    int m_seats;
};
struct Passenger
{
    char png_code[50];
    int train_no;
    char name[50];
    int age;
    char gender[10];
    char phone_no[50];
    int seat_no;
    char train_name[50];
    int t_fare;
};
struct user
{
    char password[100];
    char state[50];
    char address[1000];
    char firstname[100];
    char lastname[100];
    char mobilenumber[10];
    char email[50];
    char gender[50];
    char profession[100];
    char status[100];
    int pincode;
    char username[100];
};

typedef struct user M;
typedef struct Passenger pass_t;
typedef struct Train Trains;

void Trains_list();
void Train_Schedule();
void menu();
void Input();
void Book_Tickets();
void Cancel_Tickets();
void View_Tickets();
void Tickets();

void First_page();
void Login();
void Register();
void Login_Register();

#endif
