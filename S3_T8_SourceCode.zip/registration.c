#include<stdio.h>
#include<conio.h>
#include<string.h>
#include "structures.h"
static int index;
int registration()
{
    M multiple[100];
    int i,g,status;
    index=0;
    while((getchar())!='\n');
    printf(":::Registration desk:::\n");
    printf("Firstname :");
    gets(multiple[index].firstname);
    printf("Lastname :");
    gets(multiple[index].lastname);
    printf("Mobile number :");
    gets(multiple[index].mobilenumber);
    printf("Gender:(1.Male  2.Female  3.Other):");
    scanf("%d",&g);
    switch(g)
    {
    case 1:
        strcpy(multiple[index].gender,"Male");
        break;
    case 2:
        strcpy(multiple[index].gender,"Female");
        break;
    case 3:
        strcpy(multiple[index].gender,"Other");
        break;
    }
    printf("Martial status(1.Married  2.Unmarried):");
    scanf("%d",&status);
    switch(status)
    {
    case 1:
        strcpy(multiple[index].status,"Married");
        break;
    case 2:
        strcpy(multiple[index].status,"Unmarried");
        break;
    }
	while((getchar())!='\n');
    printf("Profession :");
    gets(multiple[index].profession);
    printf("Residential address :");
    gets(multiple[index].address);
    printf("Pin code :");
    scanf("%d",&multiple[index].pincode);
	while((getchar())!='\n');
    printf("State :");
    gets(multiple[index].state);
    printf("Email-id :");
    gets(multiple[index].email);
    strcpy(multiple[index].username,"admin");
    strcpy(multiple[index].password,"password");
    printf("Username :%s\n",multiple[index].username);
    printf("Password :%s\n",multiple[index].password);
    index++;
    return 0;
}
