#include<stdio.h>
#include<stdlib.h>
#include<windows.h>
#include "structures.h"
#include<dos.h>
#include<dir.h>
#include<string.h>
#include<conio.h>
static char c[10];
static char username[100],password[50];
//static char input[50];
void First_page()
{
    for(int i=0;i<422;i++)
    {
        printf("-");
    }
    printf("\t\t\t\t\t\t\t");
    printf("\t\t\t\t\t");
    printf("RAILWAY TICKET RESERVATION SYSTEM\n");
    for(int i=0;i<422;i++)
    {
        printf("-");
    }
    printf("1.Login\n2.New User? Register\n");
}
void Login()
{
    system("cls");
    lu:
    printf(":::Login:::\n");
    printf("Username:");
    scanf("%s",username);
    if(strcmp("admin",username)!=0)
    {
        printf("Invalid username");
        goto lu;
    }
    lp:
    printf("Password:");
    for(int i=0;i<8;i++)
    {
        password[i]=getch();
        printf("*");
    }
    if(strcmp("password",password)!=0)
    {
        printf("Invalid password");
        goto lp;
    }
    printf("\nPlease wait...");
    Sleep(1000);
    system("cls");
}
void Register()
{
    system("cls");
    registration();
    Sleep(1000);
    Login();
}
void Login_Register()
{
    scanf("%s",c);
    if(strcmp(c,"1")==0)
        Login();
    else if(strcmp(c,"2")==0)
        Register();
    else
    {
        printf("Enter a valid option:");
        Login_Register();
    }
}
