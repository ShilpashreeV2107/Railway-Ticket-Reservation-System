#include<stdio.h>
#include<conio.h>
#include<string.h>
#include<stdlib.h>
#include"structures.h"

void returnfunc();
void mainmenu_e();
void menu_e();
void student();
void old();
void job();

void mainmenu_e()
{
	system("cls");
	printf(":::E-Pass Facility:::\n");
	printf("1. Menu\n2. Exit\n\nEnter Your Choice :");
	int choice;
	scanf("%d",&choice);
	if(choice==1)
	{
		menu_e();
	}
	else if(choice==2)
	{
		system("cls");
		menu();
	}
	else
	{
		printf("\n\t     Enter valid choice.");
	}

}

void menu_e()
{
	system("cls");
	printf("You are :\n");
	printf("1. Student\n2. Senior Citizen\n3. Working Professional\n4. Back To Main Menu\n");
	printf("Enter choice :");
	int k;
	scanf("%d",&k);
		int wait;
	for(wait=0;wait<=10000;wait++)
	{
		printf("\rIn progress : %d",wait/100);
	}
	if(k==1)
	{
		system("cls");
		student();
	}
	else if(k==2)
	{
		system("cls");
		old();
	}
	else if(k==3)
	{
		system("cls");
		job();
	}
	else if(k==4)
	{
		system("cls");
		mainmenu_e();
	}
	else
	{
		printf("Wrong Input !Please Re-enter The Correct Option......\n\n");
		menu_e();
	}
}
void student()
{
	char name1[20];
	char name2[20];
    char school[20];
    char phone[50];
    int age;
    char address[40];
    char ch[10];
	printf("Please Give Your Details :\n");
	gets(ch);
	printf("First Name :");
	gets(name1);
	printf("Last Name :");
	gets(name2);
	printf("School Name :");
	gets(school);
	printf("Address :");
	gets(address);
    printf("Phone :");
	gets(phone);
	printf("Age :");
	scanf("%d",&age);
	printf("\n\n");
	printf("Entered Details:\n");
	printf("Pay Rs.450");
	system("cls");
	printf("E-Pass :\n");
	printf("First Name :%s\nLast Name :%s\nPhone :%s\nAge :%d\n Address :%s\nSchool :%s\n",name1,name2,phone,age,address,school);
	printf("\n\nPress any key to go back to main menu");
	getch();
	system("cls");
	menu_e();
}
void old()
{
	char name1[20];
	char name2[20];
    char phone[50];
    int age;
    char address[40];
	printf("Please Give Your Details :\n");
	printf("First Name :");
	while(getch!='\n');
	gets(name1);
	printf("Last Name :");
	gets(name2);
	printf("Phone :");
	gets(phone);
	printf("Age :");
	scanf("%d",&age);
	printf("\n\n");
	printf("Your Entered Details Are :\n");
	printf("Pay Rs.500");
	system("cls");
	printf("E-Pass :\n");
	printf("First Name :%s\nLast Name :%s\nPhone :%s\nAge :%d\nAddress :%s\n",name1,name2,phone,age,address);
	printf("\n\nPress any key to go back to main menu");
	getch();
	system("cls");
	menu_e();
}
void job()
{
	char name1[20];
	char name2[20];
    char phone[50];
    int age;
    char address[40];
    char work[40];
    printf("Please Give Your Details :\n");
	printf(" First Name :");
	while(getch!='\n');
	gets(name1);
	printf("Last Name :");
	gets(name2);
	printf("Address :");
	gets(address);
    printf("Work Address :");
	scanf("%s",work);
	printf("Phone :");
	gets(phone);
	printf("Age :");
	scanf("%d",&age);
	printf("\n\n");
	printf("Your Entered Details Are :\n");
	printf("Pay Rs.750");
	system("cls");
	printf("E-Pass :\n");
	printf("First Name :%s\nLast Name :%s\nPhone :%s\nAge :%d\nAddress :%s\nWork Address :%s\n",name1,name2,phone,age,address,work);
	printf("\n\nPress any key to go back to main menu");
	getch();
	system("cls");
	menu_e();
}
